######### Dijkstra algorithm for finding all shortest paths from start
def dijkstra(n,                                             # number of cities
             d,                    # distance matrix (with no negative values) 
             start):                                           # starting city

    order = [i for i in range(n)] # Cities ordered by increasing shortest path
    pred = [start] * n   # Immediate predecessor on a shortest path from start
    length = [float('inf')] * n                        # Shortest path lengths
    length[start] = 0     # Only shortest path to order[0]=start already known       
    order[0], order[start] = order[start], order[0] 

    for i in range(0, n - 1):# Update shortest path for neighbours of order[i]
        for j in range(i+1, n):                 # For all neighbours to update
            if length[order[i]] + d[order[i]][order[j]] < length[order[j]]:
                length[order[j]] = length[order[i]] + d[order[i]][order[j]]
                pred[order[j]] = order[i]
            # Update order if a better i+1th shortest path is identified
            if length[order[i+1]] > length[order[j]]:
              order[i+1], order[j] = order[j], order[i+1]

    return length, pred
