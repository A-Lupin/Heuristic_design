from random_generators import unif                               # Listing %*\ref{lst:random_generators}*)
from tsp_utilities import tsp_length                             # Listing %*\ref{lst:tsp_utilities}*)

######### Building a solution using artificial pheromone trails
def generate_solution_trail(d,                                # Distance matrix
                            tour,                    # Tour produced by the ant
                            trail):                          # Pheromone trails
    n = len(tour)
    for i in range(1, n - 1):
        total = 0
        for j in range(i + 1, n):
            total += trail[tour[i - 1]][tour[j]]
        target = unif(0, total - 1)
        j = i
        total = trail[tour[i - 1]][tour[j]]
        while total < target:
            total += trail[tour[i - 1]][tour[j + 1]]
            j += 1
        tour[j], tour[i] = tour[i], tour[j]
    return tour, tsp_length(d, tour)
