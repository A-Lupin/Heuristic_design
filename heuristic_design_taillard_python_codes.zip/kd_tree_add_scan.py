######### KD tree node data structure
class Node:

    def __init__(self, key, father, info):                 # Create a tree node
        self.key = key[:]                          # Key used to separate nodes
        self.father = father   # Father of the node, (None if node is the root)
        self.info = info[:]           # Information to store in the node (list)
        self.left = None                                     # Left son of node
        self.right = None                                           # Right son

K = 3                                     # Define the dimension of the KD tree

####################### Add a new node in a KD tree ###########################
def kd_tree_add(root,                                   # Root of a (sub-) tree 
                key,                                  # Key for splitting nodes
                info,                        # Information to store in the node
                depth):                                     # Depth of the root          

    if root is None:
        root = Node(key, None, info)
    elif root.key[depth % K] < key[depth % K]:
        if root.right is None:
            root.right = Node(key, root, info)
        else:
            root.right = kd_tree_add(root.right, key, info, depth + 1)
    else:
        if root.left is None:
            root.left = Node(key, root, info)
        else:
            root.left = kd_tree_add(root.left, key, info, depth + 1)

    return root

############# Scan a KD tree and print key and info for each node #############
def kd_tree_scan(root):    

    if root:
        if root.left:
            kd_tree_scan(root.left)
        print('Key: ', root.key, ' Info: ', root.info)
        if root.right:
            kd_tree_scan(root.right)

