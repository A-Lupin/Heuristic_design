######### Data structure building for performing 2-opt move in constant time
def build_2opt_data_structure(tour):             # Order of visit of the cities
    n = len(tour)
    t = [-1] * 2 * n
    for i in range(n - 1):                                       # Forward tour
        t[2 * tour[i]] = 2 * tour[i + 1]
    t[2 * tour[n - 1]] = 2 * tour[0]
    for i in range(1, n):                                       # Backward tour
        t[2 * tour[i] + 1] = 2 * tour[i - 1] + 1
    t[2 * tour[0] + 1] = 2 * tour[n - 1] + 1
    return t
