from random_generators import unif                               # Listing %*\ref{lst:random_generators}*)

######### Crossover operator preserving successive values in a permutation
def OX_crossover(parent1, parent2):                          # Parent solutions
    
    n = len(parent1)             
    # Randomly generate the portion of parent1 that is copied in child
    point2, point1 = unif(1, n - 2), unif(1, n - 3)
    if point1 >= point2:
        temp = point2
        point2 = point1 + 1
        point1 = temp

    # Copy the portion of parent1 at the beginning of child 
    child = [-1] * n
    inserted = [0] * n            # Flag for elements already inserted in child
    for i in range(point2 - point1 + 1):
        child[i] = parent1[i + point1] 
        inserted[child[i]] = 1

    # Last element of parent2 inserted in child
    i = parent2.index(child[point2 - point1])
 
    # Insert remaining elements in child, in order of appearance in parent2
    nr_inserted = point2 - point1 + 1
    while nr_inserted < n:
        if not inserted[parent2[i % n]]:
            child[nr_inserted] = parent2[i % n]
            inserted[parent2[i % n]] = 1
            nr_inserted += 1
        i += 1
    return child
