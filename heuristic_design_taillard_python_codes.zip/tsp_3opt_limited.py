######### POPMUSIC for the TSP based on 3-opt neighbourhood
def tsp_3opt_limited(d,                                       # Distance matrix
                     r,                                       # Subproblem size
                     succ,                         # Tour provided and returned 
                     length):                                     # Tour length
    n = len(succ)
    if r > n - 2:                       # Subproblem size must not exceed n - 2
        r = n - 2
    i = last_i = 0                                   # starting city is index 0
    while True:
        j = succ[i]
        t = 0
        # do not exceed subproblem and the limits of the neighbourhood
        while t < r and succ[succ[j]] != last_i:
            k = succ[j]
            u = 0
            while u < r and succ[k] != last_i:
                delta = d[i][succ[j]] + d[j][succ[k]] + d[k][succ[i]] \
                       -d[i][succ[i]] - d[j][succ[j]] - d[k][succ[k]]
                if delta < 0:                        # Is there an improvement?
                    length += delta                              # Perform move
                    succ[i], succ[j], succ[k] = succ[j], succ[k], succ[i] 
                    j, k = k, j                     # Replace j between i and k
                    last_i = i
                u += 1
                k = succ[k]                                            # Next k
            t += 1
            j = succ[j]                                                # Next j
        i = succ[i]                                                    # Next i
        
        if i == last_i:           # A complete tour scanned without improvement
            break

    return succ, length
