from kd_tree_add_scan import K, kd_tree_add                       #Listing %*\ref{lst:kd_tree_add_scan}*)

########## Tell if node is in the box bounded by minimum and maximum ##########
def kd_tree_in(node, 
               minimum, maximum):           # Lower and upper corner of the box
    i, result = 0, True
    while i < K and result:
        result = minimum[i] <= node.key[i] <= maximum[i]
        i = i + 1
    return result

### Find a node (if any) with its depth in the box bounded by mini and maxi ###
def kd_tree_find(root,       # Root of the tree in which the node is looked for
                 mini, maxi,                # Lower and upper corner of the box
                 depth):                                    # Depth of the root
    if root is None:
        return None, -1
    if kd_tree_in(root, mini, maxi):
        return root, depth

    if maxi[depth%K] >= root.key[depth%K]:
        result, depth_found = kd_tree_find(root.right, mini, maxi, depth + 1)
        if result:
            return result, depth_found
    if mini[depth%K] <= root.key[depth%K]:
        result, depth_found = kd_tree_find(root.left, mini, maxi, depth + 1)
        if result: 
            return result, depth_found
    return None, -1

########## Remove points of Pareto front dominated by costs (if any) ##########
def update_3opt_pareto(pareto,                 # Current Pareto front to update
                       costs,                # New point to be eventually added
                       successors, distances):      # Problem solution and data
    from kd_tree_delete import kd_tree_delete                     #Listing %*\ref{lst:kd_tree_delete}*)
    from tsp_3opt_pareto import tsp_3opt_pareto                   #Listing  %*\ref{lst:tsp_3opt_pareto}*)
    minimum = [0 for _ in range(K)]
    maximum = [float('inf') for _ in range(K)]
    dominant, depth = kd_tree_find(pareto, minimum, costs, 0)
    if dominant is None:                   # No point of pareto dominates costs
        while True:         # There are dominated points, costs improves pareto
            dominated, depth = kd_tree_find(pareto, costs, maximum, 0)
            if dominated is None:                # All dominated points removed
                break
            if dominated == pareto:
                pareto = kd_tree_delete(dominated, depth)
            else:
                dominated = kd_tree_delete(dominated, depth)

        pareto = kd_tree_add(pareto, costs, successors, 0)
        pareto = tsp_3opt_pareto(pareto, costs, successors, distances)
    return pareto

