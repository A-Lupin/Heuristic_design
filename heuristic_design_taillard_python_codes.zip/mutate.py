from random_generators import unif                               # Listing %*\ref{lst:random_generators}*)

######### Random mutation of a permutation
def mutate(mutation_rate,
           p):                                          # Permutation to mutate

    n = len(p)
    mutations = int(mutation_rate * n / 2.0)
    for _ in range(mutations):
        i = unif(0, n - 1)
        j = unif(0, n - 1)
        p[i], p[j] = p[j], p[i]
    return p
