########## Find the node with min or max value in a given dimension ###########
def kd_tree_find_opt(root,                            # Root of a KD (sub-)tree
                     dim,            # Dimension in which optimum is looked for
                     depth,                                 # Depth of the root
                     minimum,      # Look for minimum (True) or maximum (False)
                     value,                          # Best value already known
                     opt):                            # Node with optimum value
    depth_opt = -1
    if (minimum and (value > root.key[dim])) \
        or ((not minimum) and (value < root.key[dim])):
        opt = root
        value = root.key[dim]
        depth_opt = depth
    if root.left:
        opt, value, depth_opt = kd_tree_find_opt(root.left, dim, depth + 1,
                                                 minimum, value, opt)
    if root.right:
        opt, value, depth_opt = kd_tree_find_opt(root.right, dim, depth + 1,
                                                 minimum, value, opt)
    return opt, value, depth_opt

################### Delete the root of a KD (sub-) tree #######################
def kd_tree_delete(root,                                       # Node to delete
                   depth):                                  # Depth of the node
    from kd_tree_add_scan import K                                #Listing %*\ref{lst:kd_tree_add_scan}*)
    if root.left:       # Root is an internal node, must be replaced
        replacing, val_repl, depth_repl = kd_tree_find_opt(root.left, 
                              depth % K, depth + 1, False, float('-inf'), None)
    elif root.right:
        replacing, val_repl, depth_repl  = kd_tree_find_opt(root.right,
                                depth % K, depth + 1, True, float('inf'), None)
    else:                                                  # The node is a leaf
        if root.father:
            if root.father.left == root:
                root.father.left = None
            else:
                root.father.right = None
        return None                                # A leaf is directly deleted

    root.key = replacing.key[:]
    root.info = replacing.info
    kd_tree_delete(replacing, depth_repl)
    return root
