######### Inserting a child in a population of solutions
def insert_child(child,                    # Individual to insert in population
                 child_fitness,       # Cost of child (the smaller, the better)
                 population_size,                              
                 population,
                 fitness,                          # Fitness of each individual
                 order):             # order[i] : individual number with rank i

    rank = [-1 for _ in range(population_size)]           # Rank of individuals
    for i in range(population_size):
        rank[order[i]] = i

    child_rank = 0                                 # Find the rank of the child
    for i in range(population_size):
        if fitness[i] < child_fitness:
            child_rank += 1

    if child_rank < population_size - 1:           # The child is not dead-born
        if fitness[order[child_rank]] != child_fitness \
           and (child_rank == 0
                or fitness[order[child_rank - 1]] != child_fitness):
            population[order[population_size - 1]] = child[:]
            fitness[order[population_size - 1]] = child_fitness

            for i in range(population_size):
                if rank[i] >= child_rank:
                    rank[i] += 1
            rank[order[population_size - 1]] = child_rank

            for i in range(population_size):
                order[rank[i]] = i
        else:
            child_rank = population_size
    return child_rank, population, fitness, order
