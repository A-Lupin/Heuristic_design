void tsp_record_to_record(
       int n,                                                // Number of cities
       int** d,                          // Distance matrix, must be symmetrical
       int best_tour[],                  // InOut Solution provided and returned
       int* best_length,                        // InOut Length of the best tour
       int iterations)                                   // Number of iterations
{ int* tour = (int*) malloc((size_t)n * sizeof(int));        // Current solution

  for (int iter = 0; iter < iterations; ++iter)
  { memcpy(tour, best_tour, (size_t)n * sizeof(int));
    for (int shuffle = 0; shuffle < 2; ++shuffle)
      swap(&tour[unif(0,n-1)], &tour[unif(0,n-1)]);

    int length = tsp_length(n, d, tour);
    tsp_LK(n, d, tour, &length);
    if (length < *best_length)                   // Store improved best solution
    { memcpy(best_tour, tour, (size_t)n * sizeof(int));
      *best_length = length;
      printf("Record to record %d %d\n", iter, length);
    }
  }
  free(tour);
} // tsp_record_to_record
