int insert_child(int n,                                   // Size of individuals
                 const int child[],        // Individual to insert in population
                 int child_fitness,   // Cost of child (the smaller, the better)
                 int pop_size,                                // Population size
                 int **population,                       // Population to update
                 int fitness[],                        // Fitness of individuals
                 int order[])        // order[i] : individual number with rank i
{ int* rank = (int*)malloc((size_t)pop_size * sizeof(int));   // Individual rank
  for(int i = 0; i < pop_size; ++i)
    rank[order[i]] = i;                   

  int child_rank = 0;                              // Find the rank of the child
  for(int i = 0; i < pop_size; ++i)
    if(fitness[i] < child_fitness)
      ++child_rank;

  if (child_rank < pop_size - 1)                   // The child is not dead-born
  { // May the child be identical to an individual of the population ?      
    if ( fitness[order[child_rank]] != child_fitness
         && (child_rank == 0
             || fitness[order[child_rank-1]] != child_fitness) )
    { // The child not present in the population, it replace worst individual
      memcpy(population[order[pop_size-1]], child, (size_t)n * sizeof(int));
      fitness[order[pop_size-1]] = child_fitness;
      for(int i = 0; i < pop_size; ++i)
        if(rank[i] >= child_rank)
          ++rank[i];
      rank[order[pop_size-1]] = child_rank;
      for(int i = 0; i < pop_size; ++i)
        order[rank[i]] = i;
    }
    else
      child_rank = pop_size;   // Child already present in population, ignore it
  }
  free(rank);
  return child_rank;
} // insert_child
