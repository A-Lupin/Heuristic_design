/************ Local search based on 2-opt moves, best move policy *************/
void tsp_2opt_best(int n,                                    // Number of cities
                   int** d,              // Distance matrix, must be symmetrical
                   int tour[],            //InOut Solution provided and returned
                   int* length)                 // InOut Length of the best tour
{ int best_delta;                                     // Cost of best move found
  do
  { best_delta = INT_MAX;
    int best_i = -1, best_j = -1;                        // Best move to perform
    for (int i = 0; i < n - 2; ++i)                            // Find best move
    { for (int j = i + 2; (j < n) && (i > 0 || j < n - 1); ++j)
       { int delta =
           d[tour[i]][tour[j]]   + d[tour[i+1]][tour[(j+1)%n]]
         - d[tour[i]][tour[i+1]] - d[tour[j]][tour[(j+1)%n]];
          if (delta < best_delta)                      // A better move is found
          { best_delta = delta;
            best_i = i; best_j = j;
          }
      }; // for j
    }; // for i
    // Perform best move if it improves best solution
    if (best_delta < 0)
    { *length += best_delta;                             // Update solution cost
      for (int i = best_i + 1, j = best_j; i < j; ++i, --j)      // Reverse path
        swap(&tour[i], &tour[j]);                   // from best_i + 1 to best_j
    }
  } while (best_delta < 0);
} // tsp_2opt_best
