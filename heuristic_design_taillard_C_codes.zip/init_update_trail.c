void init_trail(int n,                                           // Problem size
                int value,                       // Initial value for all trails
                int **trail)                                 // Pheromone trails
{ for (int i = 0; i < n; ++i)
    for (int j = 0; j < n; ++j)
      trail[i][j] = value;
  for (int i = 0; i < n; ++i)
    trail[i][i] = 0;
} // init_trail

void update_trail(int n,                                         // Problem size
                  const int tour[],              // Last tour produced by an ant
                  const int global_best[],               // Global best solution
                  int *exploration,           // Reinforcement of local solution
                  int exploitation,     // Reinforcement of global best solution
                  int **trail)                               // Pheromone trails
{ int j = 0;
  while (j < n && tour[j] == global_best[j])
    j++;
  if (j == n)                               // Last solution same as global best
  { (*exploration)++;                         // Give more weight to exploration
    init_trail(n, *exploration, trail);
  }
  else
    for (int i = 0; i < n; ++i)
    { trail[tour[i]][tour[(i+1)%n]] += *exploration;
      trail[global_best[i]][global_best[(i+1)%n]] += exploitation;
    }
} // update_trail
