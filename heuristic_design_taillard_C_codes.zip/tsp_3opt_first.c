void tsp_3opt_first(int** d,             // Distance matrix, must be symmetrical
                    int succ[],                  // InOut Successor of each city
                    int* length)                     // InOut Length of the tour
{ int i = 0, last_i = i, j = succ[i], k = succ[j];               // Move indices
  do  
  { int delta = d[i][succ[j]] + d[j][succ[k]] +  d[k][succ[i]]      // Move cost
               -d[i][succ[i]] - d[j][succ[j]]  - d[k][succ[k]];               
    if (delta < 0)                                           // Improving move ?
    { int temp = succ[i];  succ[i] = succ[j]; 
      succ[j] = succ[k]; succ[k] = temp;                         // Perform move
      temp = j; j = k; k = temp;                    // Replace j between i and k
      *length += delta;                                  // Update solution cost
      last_i = i;                                 // Update last values of index
    }
    k = succ[k];                                                       // Next k
    if (k == i) 
      {j = succ[j]; k = succ[j];}                 // k at its last value, next j
    if (k == i) 
      {i = succ[i]; j = succ[i]; k = succ[j];}    // j at its last value, next i
  }                             // A complete tour performed without improvement
  while (succ[succ[i]] != last_i);
} // tsp_3opt_first
