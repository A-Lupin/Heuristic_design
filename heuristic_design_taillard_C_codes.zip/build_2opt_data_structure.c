int* build_2opt_data_structure(int n,                        // Number of cities
                               const int tour[])     // Order of visit of cities
{ int* t = (int*) malloc((size_t)(2 * n) * sizeof(int));
  for (int i = 0; i < n - 1; ++i)                                // Forward tour
    t[2*tour[i]] = 2*tour[i+1];
  t[2*tour[n-1]] = 2*tour[0];
  for (int i = 1; i < n; ++i)                                   // Backward tour
    t[2*tour[i]+1] = 2*tour[i-1]+1;
  t[2*tour[0]+1] = 2*tour[n-1]+1;
  return t;
} // build_2opt_data_structure
