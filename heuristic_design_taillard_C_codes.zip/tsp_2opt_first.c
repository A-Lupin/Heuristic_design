void tsp_2opt_first(int n,                                   // Number of cities
                    int** d,             // Distance matrix, must be symmetrical
                    int tour[],              // InOut Tour provided and returned
                    int* length)                     // InOut Length of the tour

{ int* t = build_2opt_data_structure(n, tour);

  int i = 0, last_i = 0;                   // Start moves evaluation from city 0
  while (t[t[i]]>>1 != last_i)     // Index i has made 1 turn without impovement
  { int j = t[t[i]];
    while (j>>1 != last_i && (t[j]>>1 != last_i || i>>1 != last_i) )
    { int delta =  d[i>>1][j>>1]    + d[t[i]>>1][t[j]>>1]
                 - d[i>>1][t[i]>>1] - d[j>>1][t[j]>>1];
      if (delta < 0)
      { int next_i = t[i], next_j = t[j];                        // Perform move
        t[i] = j^1; t[j] = i^1;
        t[next_i^1] = next_j; t[next_j^1] = next_i;

        *length += delta;                                // Update solution cost
        last_i = i >> 1;          // Solution improved: i must make another turn
        j = t[i];
      }
      j = t[j];
    } // while j
    i = t[i];
  } // while i

  // Rebuild solution: number of the city in jth position
  for (int i = 0, j = 0; j < n; i = t[i], ++j)
    tour[j] = i >> 1;
  free(t);
} // tsp_2opt_first
