/*****************************************************************************
Compile: gcc -O2 test_tsp_FANT.c
Example of execution result:

Number of cities:
200
Number of FANT iterations:
200
FANT parameter:
30
FANT 1  314
FANT 2  310
FANT 75  308
FANT 175  306
Cost of solution found with FANT 306

******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>

#include "random_generators.c"             // Code %*\ref{lst:random_generators}*)
#include "tsp_utilities.c"                 // Code %*\ref{lst:tsp_utilities}*)
#include "tsp_LK.c"                        // Code %*\ref{lst:tsp_LK}*)
#include "init_update_trail.c"             // Code %*\ref{lst:init_update_trail}*)
#include "generate_solution_trail.c"       // Code %*\ref{lst:generate_solution_trail}*)
#include "tsp_FANT.c"                      // Code %*\ref{lst:tsp_FANT}*)

int main(void)
{ int n, fant_iterations, fant_parameter;
  int *tour;
  int length;

  printf("Number of cities:\n");
  scanf("%d", &n);
  printf("Number of FANT iterations:\n");
  scanf("%d", &fant_iterations);
  printf("FANT parameter:\n");
  scanf("%d", &fant_parameter);

  tour = (int*) malloc((size_t)n * sizeof(int));
  int** distance = rand_sym_matrix(n, 1, 99);

  length = tsp_FANT(n, distance, tour, fant_parameter, fant_iterations);
  printf("Cost of solution found with FANT %d\n", length);

  for (int i = 0; i < n; ++i)
    free(distance[i]); 
  free(distance);
  free(tour);
}

