void dijkstra(int n,                                         // Number of cities
              int **d,                 // Distance matrix, without any value < 0
              int start,                                        // Starting city
              int length[],         // --> Out length[i]: Shortest length s -> i
              int pred[])          // --> Out pred[i] immediate predecessor of i
{ // Cities ordered by increasing shortest path 
  int *order = (int*) malloc ((size_t)n * sizeof(int)); 
  for (int i = 0; i < n; ++i)
  { length[i] = INT_MAX; order[i] = i;}
  length[start] = 0;
  swap(order + start, order + 0);   // Only shortest path to start already known
 
  for (int i = 0; i < n - 1; ++i)    // Identify all shortest paths successively
    for(int j = i + 1; j < n; ++j)
    { if (length[order[i]] + d[order[i]][order[j]] < length[order[j]])
      { length[order[j]] = length[order[i]] + d[order[i]][order[j]];
        pred[order[j]] = order[i]; 
      }
      if (length[order[i+1]] > length[order[j]])
        swap(order + i+1, order + j); // A better i+1th shortest path identified
    }
  free(order);
 } // dijkstra
