void tsp_3opt_limited(int n,                                 // Number of cities
                      int** d,                                // Distance matrix
                      int r,                                  // Subproblem size
                      int succ[],                 //InOut Successor of each city
                      int* length)                          // InOut Tour length

{ if (r > n - 2)                   // Max subpath length should not exceed n - 2
    r = n - 2;

  int i = 0, last_i = 0;              // Start moves evaluation from city  i = 0
  do
  { for (int j = succ[i], t=0; t<r && succ[succ[j]]!=last_i ; ++t, j = succ[j])
      for (int k = succ[j], u = 0; u < r && succ[k] != last_i; ++u, k = succ[k])
      {
        int delta = d[i][succ[j]] + d[j][succ[k]] + d[k][succ[i]]   // Move cost
                   -d[i][succ[i]] - d[j][succ[j]] - d[k][succ[k]];
        if (delta < 0)                                       // Improving move ?
        { int tmp = succ[i];  succ[i] = succ[j]; 
          succ[j] = succ[k]; succ[k] = tmp;                      // Perform move
          tmp = j; j = k; k = tmp;                  // Replace j between i and k
          *length += delta;                              // Update solution cost
          last_i = i;                           // Update last values of index i
        }
      }
    i = succ[i];
  }
  while (i != last_i);            // A complete tour scanned without improvement
} // tsp_3opt_limited
