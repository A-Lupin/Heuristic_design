typedef int KEY[K];                                         // K-dimensional key
typedef struct NODE NODE, *KD_TREE;                         // Node of a KD tree
struct NODE{KEY key;            // A node split the tree according to key[depth]
            int *info;        // Access of an array for the information to store
            KD_TREE r; KD_TREE L;};                   // Right and left subtrees


/********************** Create a new KD tree node *****************************/
KD_TREE KD_init(const KEY key, int n, const int *info)
{ KD_TREE root = (KD_TREE) malloc(sizeof(NODE));           
  memcpy(root->key, key, sizeof(KEY));
  root->info = (int*) malloc((size_t)n * sizeof(int));
  memcpy(root->info, info, (size_t)n * sizeof(int));
  root->L = root->r = NULL;
  return root;
}

/*********************** Add element to KD-Tree tree **************************/
void KD_add(KD_TREE *root, const KEY key, int n, const int *info, int depth)
{ if (*root == NULL)
    *root = KD_init(key, n, info);
  else if ((*root)->key[depth%K] < key[depth%K])
    KD_add(&(*root)->r, key, n, info, depth + 1);
  else
    KD_add(&(*root)->L, key, n, info, depth + 1);
}

/********** Enumerate all the elements of a KD-tree and free memory ***********/
void KD_scan_and_delete(KD_TREE root, int n)
{ if (root != NULL)
  { KD_scan_and_delete(root -> L, n);

    printf("Key: ");
    for (int k = 0; k < K; ++k)       
         printf("%d ", root->key[k]);
    printf("Info array: ");
    for (int i = 0; i < n; ++i)       
         printf("%d ", root->info[i]);
    putchar('\n');

    KD_scan_and_delete(root -> r, n);
    free(root->info);
    free(root);
  }
}
