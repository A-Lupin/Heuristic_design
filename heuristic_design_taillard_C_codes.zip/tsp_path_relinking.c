void tsp_path_relinking(int n,                               // Number of cities
                        int** d,                              // Distance matrix
                        const int target[],     // Arrival solution (successors)
                        int best_succ[],       // Starting sol. --> Best on path
                        int* best_length)      // Starting solution cost -> best
{ int length = *best_length;                         // Cost of current solution
  int *succ, *pred;              // Current solution (forward and backward tour)
  succ = (int*) malloc((size_t)n * sizeof(int));
  memcpy(succ, best_succ, (size_t)n * sizeof(int));
  pred = (int*) malloc((size_t)n * sizeof(int));
  tsp_succ_to_pred(n, succ, pred);
  int best_delta;
  do
  { int i = 0, best_i, best_j, best_k;              // Move index, retained move
    best_delta = INT_MAX;
    do
    { if (succ[i] != target[i])                  // try i-succ[i] -> i-target[i]
      { int j = pred[target[i]];             // j-succ[j] not in target solution
        for (int k = target[i]; k != i; k = succ[k]) 
          if (succ[k] != target[k]) 
          { int delta =  d[i][succ[j]] + d[j][succ[k]] + d[k][succ[i]] 
                        -d[i][succ[i]] - d[j][succ[j]] - d[k][succ[k]];
            if (delta < best_delta)
            { best_delta = delta;
              best_i = i; best_j = j; best_k = k;
            }
          }        
      }
      i = succ[i];
    }
    while (best_delta >= 0 && i != 0);      //Impr. move found or target reached

    if (best_delta < INT_MAX)                           // A move has been found
    { int i = best_i, j = best_j, k = best_k;
      length += best_delta;
      pred[succ[i]] = k; pred[succ[j]] = i; pred[succ[k]] = j;
      succ[j] = succ[k]; succ[k] = succ[i]; succ[i] = target[i];
      if (length < *best_length)
      { *best_length = length;
        memcpy(best_succ, succ, (size_t)n * sizeof(int));
      }
    }
  }
  while (best_delta < INT_MAX);
  free(succ); free(pred);
} // tsp_path_relinking
