int tsp_GA(int n,                                            // Number of cities
           int** d,                                           // Distance matrix
           int best_tour[],                             // Out Solution returned
           int population_size,                        // Size of the population
           int generations,                      // Number of children generated
           double mutation_rate)
{ // Generate a population of random solutions
  int** population = (int**) malloc((size_t)population_size * sizeof(int*));
  int* length = (int*) malloc((size_t)population_size * sizeof(int));
  for(int i = 0; i < population_size; ++i)
  { population[i] = (int*) malloc((size_t)n * sizeof(int));
    rand_permutation(n, population[i]);
    length[i] = tsp_length(n, d, population[i]);
  }
  // order the individual by decreasing fitness and assign them an order
  int* order;                        // order[i] : individual number with rank i
  order = (int*) malloc((size_t)population_size * sizeof(int));
  for(int i = 0; i < population_size; ++i)
    order[i] = i;

  for(int i = 0; i < population_size - 1; ++i)
    for(int j = i + 1; j < population_size; ++j)
      if(length[order[i]] > length[order[j]])
        swap(order + i,  order + j);
  printf("GA initial best individual %d \n", length[order[0]]);

  /*********                           Main GA loop                    ********/
  int* child = (int*)malloc((size_t)n * sizeof(int));          // child-solution
  for(int gen = 0; gen < generations; ++gen)
  { // Generate a new child
    int parent1 = rank_based_selection(population_size),
        parent2 = rank_based_selection(population_size);
    OX_crossover(n, population[order[parent1]], population[order[parent2]],
                 child);
    mutate(n, mutation_rate, child);
    int child_length = tsp_length(n, d, child);
    tsp_LK(n, d, child, &child_length);
    if(insert_child(n, child, child_length,
       population_size, population, length, order) == 0)
      printf("GA imroved tour %d %d \n", gen, child_length);
  }
  // Return the best solution of the population
  memcpy(best_tour, population[order[0]], (size_t)n * sizeof(int));

  free(child);
  free(length);
  free(order);
  for(int i = 0; i < population_size; ++i)
    free(population [i]);
  free(population);
  return tsp_length(n, d, best_tour);
} // tsp_GA
