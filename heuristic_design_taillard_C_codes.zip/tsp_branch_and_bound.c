void tsp_branch_and_bound(int n, int** d,   // Number of cities, distance matrix
                          int depth,        // current_tour [0] to [depth] fixed
                          int current_tour[],        // Solution partially fixed
                          int best_tour[],           // --> in out: optimum tour
                          int* upper_bound)   // --> in out: optimum tour length
{ for (int i = depth; i < n; i++)
  { int* tour = (int*)malloc((size_t)n * sizeof(int));
    memcpy(tour, current_tour, (size_t)n * sizeof(int));
    swap(tour+depth, tour+i);
    int valid;
    int lb = tsp_lower_bound(n, d, depth, tour, &valid);
    if (*upper_bound > lb)
    { if (valid)
      { *upper_bound = lb; memcpy(best_tour, tour, (size_t)n * sizeof(int));
        printf("Improved: %d\n", *upper_bound);
      }
      else
        tsp_branch_and_bound(n, d, depth + 1, tour, best_tour, upper_bound);
    }
    free(tour);
  }
} // tsp_branch_and_bound
