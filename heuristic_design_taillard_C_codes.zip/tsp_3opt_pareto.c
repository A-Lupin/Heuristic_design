/* Function update_pareto_3opt built neighbour solutions, if necessary        */
/* It recursively calls tsp_3opt_pareto with the neighbour solutions          */
void update_pareto(KD_TREE* pareto, KEY costs, int n, int* info, int*** data);

void tsp_3opt_pareto(KD_TREE* pareto,      // Pareto set updated with neighbours
                     KEY costs,      // The different objectives of the solution
                     int n,                                  // Number of cities
                     int* succ,             // Solution (successor of each city)
                     int*** d)       // Distance matrices, symmetry not required

{ int i = unif(0, n - 1), last_i = i, j = succ[i], k = succ[j];  // Move indices
  KEY costs_neighbour;                          // Costs of a neighbour solution
  do
  { for (int dim = 0; dim < K; ++dim)
      costs_neighbour[dim] = costs[dim]  
                 + d[dim][i][succ[j]] + d[dim][j][succ[k]] + d[dim][k][succ[i]]  
                 - d[dim][i][succ[i]] - d[dim][j][succ[j]] - d[dim][k][succ[k]];
    // Temporary modification of the solution for creating a neighbour
    int tmp = succ[i]; succ[i] = succ[j]; succ[j] = succ[k]; succ[k] = tmp;
    update_pareto(pareto, costs_neighbour, n, succ, d);             // Code %*\ref{lst:update_pareto}*)
    succ[k] = succ[j]; succ[j] = succ[i]; succ[i] = tmp;     // Back to solution
    k = succ[k];                                                       // Next k
    if (k == i) 
      {j = succ[j]; k = succ[j];}                 // k at its last value, next j
    if (k == i) 
      {i = succ[i]; j = succ[i]; k = succ[j];}    // j at its last value, next i
  }                                              
  while (succ[succ[i]] != last_i);               // Whole neighbourhood examined
} // tsp_3opt_pareto
