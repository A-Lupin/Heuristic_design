int tsp_nearest_neighbour(int n,                             // Number of cities
                          int** d,                            // Distance matrix
                          int tour[])                 // List of cities to order
{ int length = 0;                                                 // Tour length

  for (int i = 1; i < n; ++i)      // Cities from tour[0] to tour[i-1] are fixed
  { int nearest = i;                              // Next nearest city to insert
    int cost_ins = d[tour[i-1]][tour[i]];                 // City insertion cost
    for(int j = i + 1; j < n; ++j)                   // Find next city to insert
       if (d[tour[i-1]][tour[j]] < cost_ins)
       { cost_ins = d[tour[i-1]][tour[j]]; 
         nearest = j;
       }
    length += cost_ins;
    swap(tour + i, tour + nearest);           // Next city definitively inserted
  }
  return length + d[tour[n-1]][tour[0]];
} // tsp_nearest_neighbour
