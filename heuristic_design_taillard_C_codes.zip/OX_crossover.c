void OX_crossover(int n,                                     // Number of cities
                  const int parent1[], const int parent2[],           // Parents
                  int child[])                                 // Child produced
{ // Randomly generate the portion of parent1 that is copied in child
  int point2 = unif(1, n - 2);
  int point1 = unif(1, n - 3);
  if (point1 >= point2)
  { int temp = point2;
    point2 = ++point1;
    point1 = temp;
  }

  // Copy the portion of parent1 at the beginning of child
  int *inserted = (int*) calloc((size_t)n, sizeof(int));   // Elements inserted?
  for(int i = 0; i < point2 - point1 + 1; ++i)
  { child[i] = parent1[i + point1];
    inserted[child[i]] = 1;
  }
  // Find in parent2 the last element inserted in child
  int last = 0;
  while (parent2[last] != child[point2-point1])
    ++last;

  // Insert remaining elements in child, in order of appearance in parent2
  int nr_inserted = point2 - point1 + 1;
  for(int i = last; nr_inserted < n; ++i)
    if (!inserted[parent2[i%n]])
    { child[nr_inserted] = parent2[i%n];
      inserted[parent2[i%n]] = 1;
      ++nr_inserted;
    }
  free(inserted);
} // OX_crossover
