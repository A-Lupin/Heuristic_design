int tsp_pilot_nearest_neighbour(int n,                       // Number of cities
                                int** d,                      // Distance matrix
                                int tour[])         // ->Out Order of the cities
{ int *sol = (int*) malloc((size_t)n * sizeof(int));         // Copy of solution

  for (int i = 0; i < n; ++i)                      // All cities must be in tour
    tour[i] = i;

  for (int q = 0; q < n - 1; ++q)      // Cities up to q at their final position
  { int length_r = tsp_length(n, d, tour);
    int to_insert = q;
    for (int r = q; r < n; ++r)    // Choose next city to inserted at position q
    { memcpy(sol, tour, (size_t)n * sizeof(int));         // Copy of tour in sol
      swap (sol+q, sol+r);      // Tentative solution with tour[q] at position r
      tsp_nearest_neighbour(n - q, d, sol + q);              // Pilot heuristics
      int tentative_length = tsp_length(n, d, sol);
      if (length_r > tentative_length)
      { length_r = tentative_length;
        to_insert = r;
      }
    } // for r
    swap(tour + to_insert, tour + q);     // Definitive position q for to_insert
  } // for q 
  
  free(sol);
  return tsp_length(n, d, tour);
 } // tsp_pilot_nearest_neighbour
