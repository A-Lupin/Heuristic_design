/*****************************************************************************
Compile: gcc -O2 test_tsp_GA.c -lm
Example of execution result:

Number of cities:
200
Size of the population, mutation rate, number of generations:
10 0.01 60
GA initial best individual 9424 
GA imroved tour 0 315 
GA imroved tour 2 312 
GA imroved tour 29 308 
Cost of solution found with GA: 308

******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "random_generators.c"             // Code %*\ref{lst:random_generators}*)
#include "tsp_utilities.c"                 // Code %*\ref{lst:tsp_utilities}*)
#include "tsp_LK.c"                        // Code %*\ref{lst:tsp_LK}*)
#include "rank_based_selection.c"          // Code %*\ref{lst:rank_based_selection}*)
#include "OX_crossover.c"                  // Code %*\ref{lst:OX_crossover}*)
#include "mutate.c"                        // Code %*\ref{lst:mutate}*)
#include "insert_child.c"                  // Code %*\ref{lst:insert_child}*)
#include "tsp_GA.c"                        // Code %*\ref{lst:tsp_GA}*)

int main(void)
{ int n, population_size, nr_generations;
  int length;
  double mutation_rate;

  printf("Number of cities:\n");
  scanf("%d",&n);
  printf("Size of the population, mutation rate, number of generations:\n");
  scanf("%d%lf%d",&population_size, &mutation_rate, &nr_generations);

  int* solution = (int*) malloc((size_t)n * sizeof(int));
  int** distance = rand_sym_matrix(n, 1, 99);
    
  length = tsp_GA(n, distance, solution, population_size,
                  nr_generations, mutation_rate);
  printf("Cost of solution found with GA: %d\n", length);

  for (int i = 0; i < n; ++i)
    free(distance[i]); 
  free(distance);
  free(solution);
}

