void tsp_TS(int n,                                           // Number of cities
            int** d,                     // Distance matrix, must be symmetrical
            int best_tour[],                 // InOut Tour provided and returned
            int* best_length,                   // InOut Length of the best tour
            int iterations,                           // Number of TS iterations
            int min_tabu_duration,                 // Minimal forbidden duration
            int max_tabu_duration,
            double F)        // Factor for penalizing moves repeatedly performed
{ int length = *best_length;                           // Length of current tour
  int* tour = (int*)malloc((size_t)n * sizeof(int));             // Current tour
  memcpy(tour, best_tour, (size_t)n * sizeof(int));  
  // Initialization of tabu list: any move initially allowed
  int** tabu = (int**) malloc((size_t)n * sizeof(int*));
  for (int i = 0; i < n; ++i) tabu[i] = (int*) calloc((size_t)n, sizeof(int));
  int** count = (int**) malloc((size_t)n * sizeof(int*));          // Move count
  for (int i = 0; i < n; ++i) count[i] = (int *) calloc((size_t)n, sizeof(int));
  for (int iter = 1; iter <= iterations; ++iter)        // Main tabu search loop
  { double delta_penalty = DBL_MAX;
    int ir = -1, jr = -1;               // Cities retained for performing a move
    for (int i = 0; i < n - 2; ++i)         // Find best move allowed or aspired
    { for (int j = i + 2; (j < n) && (i > 0 || j < n - 1); ++j)
      { int delta =   d[tour[i]][tour[j]]   + d[tour[i+1]][tour[(j+1)%n]]
                    - d[tour[i]][tour[i+1]] - d[tour[j]][tour[(j+1)%n]];
        double penalty = F*(count[tour[i]][tour[j]] +
                            count[tour[i+1]][tour[(j+1)%n]]);
        int better = delta + penalty < delta_penalty;     // A better move found
        int allowed = tabu[tour[i]][tour[j]] <= iter             // Move allowed      
                      || tabu[tour[i+1]][tour[(j+1)%n]] <= iter;
        int aspirated = length + delta < *best_length;         // Move aspirated
        if (better && (allowed || aspirated) )                  
        { delta_penalty = delta + penalty; 
          ir = i; jr = j;
        }
      } //for j
    } // for i 
    if (delta_penalty < DBL_MAX)                        // Perform move retained
    {   tabu[tour[ir]][tour[ir+1]] = tabu[tour[jr]][tour[(jr+1)%n]]
      = tabu[tour[ir+1]][tour[ir]] = tabu[tour[(jr+1)%n]][tour[jr]] 
      = unif(min_tabu_duration, max_tabu_duration) + iter; 

      count[tour[ir]][tour[jr]]++; count[tour[jr]][tour[ir]]++;
      count[tour[ir+1]][tour[(jr+1)%n]]++; count[tour[(jr+1)%n]][tour[ir+1]]++;

      length +=  d[tour[ir]][tour[jr]] + d[tour[ir+1]][tour[(jr+1)%n]]
               - d[tour[ir]][tour[ir+1]] - d[tour[jr]][tour[(jr+1)%n]];
      for (int k = 0; k < (jr - ir) / 2; ++k)                    // Reverse path
        swap(tour + (k + ir + 1), tour + (jr - k));                               
    }
    else printf("All moves are forbidden: tabu list too long\n");

    if (length < *best_length)                // Store best solution if improved
    { *best_length = length;
      memcpy(best_tour, tour, (size_t)n * sizeof(int));  
      printf("TS %d %d\n", iter, length);
    }
  } // for iter
  for (int i = 0; i < n; ++i) free(count[i]);
  free(count);
  for (int i = 0; i < n; ++i) free(tabu[i]);
  free(tabu); free(tour);
} // tsp_TS
