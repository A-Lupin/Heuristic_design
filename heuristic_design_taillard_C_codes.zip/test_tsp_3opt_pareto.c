/*****************************************************************************
Compile: gcc -O2 test_tsp_3opt_pareto.c
******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#define K 3                                              // Number of objectives

#include "random_generators.c"          // Code %*\ref{lst:random_generators}*)
#include "tsp_utilities.c"              // Code %*\ref{lst:tsp_utilities}*)
#include "kd_tree_add_scan.c"           // Code %*\ref{lst:kd_tree_add_scan}*)
#include "kd_tree_delete.c"             // Code %*\ref{lst:kd_tree_delete}*)
#include "tsp_3opt_pareto.c"            // Code %*\ref{lst:tsp_3opt_pareto}*)
#include "kd_tree_update_pareto.c"      // Code %*\ref{lst:kd_tree_update_pareto}*)

int main(void)
{ int n; 
  printf("Number of cities:\n");
  if (scanf("%d",&n) == 0)
    return EXIT_FAILURE;
  
  int ***distance = (int***) malloc((size_t)K * sizeof(int**));
  for (int dim = 0; dim < K; ++dim)
    distance[dim] = rand_sym_matrix(n, 1, 99);

  int *succ = (int*) malloc((size_t)n * sizeof(int));  // Successor of each city
  for (int i = 0; i < n; ++i)                    // Generate a starting solution
    succ[i] = (i + 1) % n;

  KEY lengths;
  for (int dim = 0; dim < K; ++dim)   //Compute solution cost for all objectives
  { lengths[dim] = 0;
    for (int i = 0; i < n; ++i)
      lengths[dim] += distance[dim][i][succ[i]];
  }

  KD_TREE pareto_front = NULL;
  tsp_3opt_pareto(&pareto_front, lengths, n, succ, distance);
  KD_scan_and_delete(pareto_front, n);

  for (int dim = 0; dim < K; ++dim)
  { for (int i = 0; i < n; ++i)
      free(distance[dim][i]); 
    free(distance[dim]);
  }
  free(distance);
  free(succ);
}

