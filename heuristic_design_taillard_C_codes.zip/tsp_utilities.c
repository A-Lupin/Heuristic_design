/******************** Compute the length of a TSP tour ************************/
int tsp_length(int n,                                        // Number of cities
               int** d,                                       // Distance matrix
               const int tour[])                          // Order of the cities
{ int length = d[tour[n - 1]][tour[0]];
  for (int i = 0; i < n - 1; ++i)
    length += d[tour[i]][tour[i + 1]];
  return length;
}

/*************** Build solution representation by successors ******************/
void tsp_tour_to_succ(int n, const int tour[], int succ[])
{ for (int i = 0; i < n; ++i)  
    succ[tour[i]] = tour[(i + 1) % n];
}

/************** Build solution representation by predeccessors *****************/
void tsp_succ_to_pred(int n, const int succ[], int pred[])
{ for (int i = 0; i < n; ++i)       
    pred[succ[i]] = i;
}

/********** Convert solution from successor of each city to city order ********/
void tsp_succ_to_tour(int n, const int succ[], int tour[])
{ int j = 0;
  for (int i = 0; i < n; ++i)
  {
    tour[i] = j; 
    j = succ[j];
  }
}

/**** Convert a solution given by 2-opt data structure to a standard tour *****/
void tsp_2opt_data_structure_to_tour(int n, const int t[], int tour[])
{ int j = 0;
  for (int i = 0; i < n; ++i)
  {
    tour[i] = j>>1;
    j = t[j];
  }
}

/******* Compare 2 directed tours; returns the number of different arcs *******/
int tsp_compare(int n, const int succ_a[], const int succ_b[])
{ int count = 0;
  for (int i = 0; i < n; ++i)
    count += succ_a[i] != succ_b[i];
  return count;
}
