void tsp_VNS(int n,                                          // Number of cities
             int **d,                    // Distance matrix, must be symmetrical
             int best_tour[],                // InOut tour provided and returned
             int *best_length)                  // InOut Length of the best tour
{ int* tour = (int *) malloc((size_t)n * sizeof(int));
  int iteration = 0;                                    // Number of 2-opt calls
  int k = 1;
  while (k < n)
  { memcpy(tour, best_tour, (size_t)n * sizeof(int));
    for (int i = 0; i < k; ++i)                           // Perturbate solution
      swap(tour + unif(0,n - 1), tour + unif(0,n - 1));

    int length = tsp_length(n, d, tour);
    tsp_LK(n, d, tour, &length);
    iteration++;
    if (length < *best_length)                       // Store improved best tour
    { memcpy(best_tour, tour, (size_t)n * sizeof(int));
      *best_length = length;
      printf("VNS %d %d %d\n", iteration, k, length);
      k = 1;
    }
    else
      ++k;                                               // Neighbourhood change
  }
  free(tour);
} // tsp_VNS
