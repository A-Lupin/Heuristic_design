void tsp_LK(int n,                                           // Number of cities
            int** D,                     // Distance matrix, must be symmetrical
            int tour[],                   //InOut Solution provided and returned
            int* length)                        // InOut Length of the best tour
{ int* succ = (int*) malloc((size_t)n * sizeof(int));      //  succ of each city
  tsp_tour_to_succ(n, tour, succ);
  int **tabu =(int**)malloc((size_t)n*sizeof(int*));     //Can remove edge i-j ?
  for (int i = 0; i < n; ++i)
    tabu[i] = (int*) calloc((size_t)n, sizeof(int));
  int iteration = 0;        // Outermost loop counter to identify tabu condition
  int last_a = 0, a = 0;              // Initiate ejection chain from city a = 0
  int improved = 1;                                            // succ modified?
  while (a != last_a || improved)
  { improved = 0;
    ++iteration;
    int b = succ[a], path_length = *length - D[a][b], path_modified = 1;
    while (path_modified)    // Identify best ref. struct. with edge a-b removed
    { path_modified = 0;
      int ref_struct_cost = *length;     // Cost of reference structure retained
      int best_c = succ[b], c = succ[b];
      while (succ[c] != a)                         // Ejection can be propagated
      { int d = succ[c];
        if (path_length - D[c][d] + D[c][a] + D[b][d] < *length)
        { best_c = c;                     // An improving solution is identified
          ref_struct_cost = path_length - D[c][d] + D[c][a] + D[b][d];
          break;                        // Change improving solution immediately
        }
        if (tabu[c][d] != iteration         // Edge c - d has not been added yet
            && path_length + D[b][d] < ref_struct_cost)
        { ref_struct_cost = path_length + D[b][d];
          best_c = c;
        }
        c = d;                                         // Next value for c and d
      } //while succ[c] != a
      if (ref_struct_cost < *length)     // Admissible reference structure found
      { path_modified = 1;
        c = best_c;
        int d = succ[c];                           // Update reference structure
        tabu[c][d] = tabu[d][c] = iteration;    // Prevent remove again edge c-d
        path_length += (D[b][d] - D[c][d]);
        int i = b, si = succ[b];                          // Reverse path b -> c
        succ[b] = d;
        while (i != c)
        { int tmp = succ[si]; succ[si] = i; i = si; si = tmp;}
        b = c;
        if (path_length + D[a][b] < *length)       // A better solution is found
        { *length = path_length + D[a][b];
          last_a = succ[a] = b;
          improved = 1;
          tsp_succ_to_tour(n, succ, tour);
        }
      }
    } // while path_modified
    tsp_tour_to_succ(n, tour, succ);
    a = succ[a];
  } // while a != last_a
  for (int i = 0; i < n; ++i)
    free(tabu[i]);
  free(tabu);
  free(succ);
} // tsp LK
