int tsp_FANT(int n,                                          // Number of cities
             int** d,                                         // Distance matrix
             int best_sol[],                            // Out Solution returned
             int exploitation,         // FANT Parameters: global reinforcement,
             int iterations)                  // number of solutions to generate
{ int exploration = 1;    // Reinforcement of elements of the solution generated
  int best_cost = INT_MAX;                            // Length of the best tour
  int* tour = (int*) malloc((size_t)n * sizeof(int));      // Solution generated
  rand_permutation(n, tour);
  int** trail = (int**)malloc((size_t)n * sizeof(int*));     // Pheromone matrix
  for (int i = 0; i < n; ++i)
    trail[i] = (int*) malloc((size_t)n * sizeof(int));
  init_trail(n, exploration, trail);

  for (int i = 1; i <= iterations; ++i) // FANT iterations
  { int cost = generate_solution_trail(n, d, tour, trail);  //Build new solution
    tsp_LK(n, d, tour, &cost);           // Improve solution with a local search

    if (cost < best_cost)                            // Best solution improved ?
    { best_cost = cost;
      printf("FANT %d  %d\n", i, cost);
      memcpy(best_sol, tour, (size_t)n * sizeof(int));
      exploration = 1;                      // Reset exploration to lowest value
      init_trail(n, exploration, trail); 
    }
    else
      update_trail(n, tour, best_sol, &exploration, exploitation, trail);
  };

  free(tour);
  for (int i = 0; i < n; ++i)
    free(trail[i]);
  free(trail);
  return best_cost;
} // tsp_FANT

