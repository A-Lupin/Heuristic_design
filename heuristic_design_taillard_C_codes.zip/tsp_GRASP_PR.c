int tsp_GRASP_PR(int n,                                      // Number of cities
                 int** d,                                     // Distance matrix
                 int best_tour[],                       // Out Solution returned
                 int population_size,                  // Size of the population
                 int iterations,                         // Number of iterations
                 double alpha)                                // GRASP parameter
{ // Generate a population of solutions
  int** population = (int**) malloc((size_t)population_size * sizeof(int*));
  int* lengths = (int*) malloc((size_t)population_size * sizeof(int));
  int* tour = (int*) malloc((size_t)n * sizeof(int));            // Working tour
  int* succ = (int*) malloc((size_t)n * sizeof(int));      // Working successors
  int length;
  int iter = 0;                         // Counting the number of calls to GRASP
  for(int i = 0; i < population_size; ++i)
  { population[i] = (int*) malloc((size_t)n * sizeof(int));
    int different = 1;
    do
    { length = tsp_GRASP(n, d, tour, alpha);
      iter++;
      tsp_tour_to_succ(n, tour, succ);
      for (int j = 0; different > 0 && j < i; ++j)
        different = tsp_compare(n, population[j], succ);
    }
    while (different == 0 && iter < iterations);
    tsp_tour_to_succ(n, tour, population[i]);
    lengths[i] = length;
    if (iter == iterations)      // Unable to generate a population large enough
      population_size = i;
  }
  // Path relinking from a new solution generated with GRASP
  for (int it = iter; it < iterations; ++it)
  { length = tsp_GRASP(n, d, tour, alpha);
    tsp_tour_to_succ(n, tour, succ);
    tsp_path_relinking(n, d, population[unif(0, population_size - 1)],
                       succ, &length);
    int max_difference = -1, replacing = -1;
    for (int i = 0; i < population_size && max_difference != 0; ++i)
      if (lengths[i] >= length)
      { int difference = tsp_compare(n, population[i], succ);
        if (difference == 0)            // Tour already in population; ignore it
        { max_difference = 0; break;}
        if (difference > max_difference && lengths[i] > length)
        { max_difference = difference;
          replacing = i;
        }
      }
    if (max_difference > 0)
    { printf("GRASP_PR population updated: %d %d\n", it, length);
      lengths[replacing] = length;
      memcpy(population[replacing], succ, (size_t)n * sizeof(int));
    }
  }
  int best = 0;
  for (int i = 1; i < population_size; ++i)
    if (lengths[i] < lengths[best])
      best = i;
  tsp_succ_to_tour(n, population[best], best_tour);

  free(lengths);
  for(int i=0; i < population_size; ++i)
    free(population [i]);
  free(population);
  return tsp_length(n, d, best_tour);
} // tsp_GRASP_PR
