/*** Find the root of tree with max or min (=1) coordinate in dimension dim ***/
KD_TREE* KD_find_opt(KD_TREE *tree, int dim, int depth, int min, 
                     KD_TREE *opt, int *value, int *depth_opt)
{ int val = (*tree)->key[dim];
  if ((min && *value > val) || (!min && *value < val) )
  { opt = tree;
    *value = val;
    *depth_opt = depth;
  }
  if ((*tree)->L != NULL)
    opt = KD_find_opt(&(*tree)->L, dim, depth+1, min, opt, value, depth_opt);
  if ((*tree)->r != NULL)
    opt = KD_find_opt(&(*tree)->r, dim, depth+1, min, opt, value, depth_opt);
  return opt;
}

/********* Remove the root node from a (sub-)KD-tree knowing its depth ********/  
void KD_delete(KD_TREE *root, int depth)
{ if ( (*root)->L == NULL && (*root)->r == NULL )
  {  free( (*root)->info );
    free(*root);
    *root = NULL;
    return;
  }

  KD_TREE* replacing;                 // Node that will replace the removed node
  int val_repl;
  int depth_repl;
  if ((*root)->L != NULL)     // Find replacing node with max coordinate at left
  { val_repl = INT_MIN;
    replacing = KD_find_opt(&(*root)->L, depth%K, depth+1, 0,
                            NULL, &val_repl, &depth_repl);
  }
  else                   // Find replacing node with minimal coordinate at right
  { val_repl = INT_MAX;
    replacing = KD_find_opt(&(*root)->r, depth%K, depth+1, 1,
                            NULL, &val_repl, &depth_repl);
  }

  memcpy((*root)->key, (*replacing)->key, K*sizeof(int));
  int *tmp = (*root)->info; (*root)->info = (*replacing)->info;
  (*replacing)->info = tmp;

  KD_delete(replacing, depth_repl);
}
