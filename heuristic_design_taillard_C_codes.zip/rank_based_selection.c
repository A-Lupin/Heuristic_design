int rank_based_selection(int size)
{ return size - (int)ceil(sqrt(0.25 + 2 * unif(1, size*(size + 1) / 2)) - 0.5);}
