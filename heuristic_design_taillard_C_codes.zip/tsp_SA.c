void tsp_SA(int n,                                           // Number of cities
            int** d,                     // Distance matrix, must be symmetrical
            int best_tour[],                                   // InOut TSP tour
            int* best_length,                   // InOut Length of the best tour
            double initial_temperature,                         // SA Parameters
            double final_temperature,
            double alpha)

{ int length = *best_length;                           // Length of current tour
  double T = initial_temperature;                         // Current temperature

  int* t = build_2opt_data_structure(n, best_tour);

  long iteration = 0;                          // Number of iterations performed
  while (T > final_temperature)         // Repeat, while temperature high enough
  { int i = unif(0, n - 1), last_i = i;  // First city of a move randomly chosen
    while (t[t[i]]>>1 != last_i && t[i]>>1 != last_i)   //  */
     {int j = t[t[i]];
      while (j>>1 != last_i && (t[j]>>1 != last_i || i>>1 != last_i) )
      { int delta = d[i>>1][j>>1]    + d[t[i]>>1][t[j]>>1]
                   -d[i>>1][t[i]>>1] - d[j>>1][t[j]>>1];
        if (delta < 0 || exp(-delta/T) > rando())               // Move accepted
        { int next_i = t[i], next_j = t[j];
          t[i] = j^1; t[next_i^1] = next_j;
          t[j] = i^1; t[next_j^1] = next_i;
          length = length + delta;
          i = t[i];               // Avoid immediate reverse of a degrading move
          j = t[i];

         if (length < *best_length)              // Store improved best solution
          { *best_length = length;
            // Rebuild the solution under the form of the sequence of cities 
            for (int r = 0, s = 0; s < n; ++s, r = t[r])
              best_tour[s] = r>>1;
            printf("SA %ld %d\n", iteration, length);
          }
        }    // Move accepted */

        ++iteration;
        if (iteration % (n*n) == 0)  // Temperature decrease every n*n iteration
          T *= alpha;
        j = t[j]; // Next j
      }
      i = t[i]; // Next i
    }
  }    // while (T > final_temperature)
  free(t);
} // tsp_SA
