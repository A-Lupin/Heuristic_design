int tsp_GRASP(int n,                                         // Number of cities
              int** d,                   // Distance matrix, must be symmetrical
              int tour[],                                          // Tour built
              double alpha)                 // Randomness in greedy construction
{ rand_permutation(n, tour);                   // Tour starts from a random city
  for (int i = 0; i < n - 1; ++i)    // tour[i]: last city definitively selected
  { // Determine min and max incremental costs
    int cmin = INT_MAX, cmax = INT_MIN;
    for (int j = i + 1; j < n; ++j)
    { if (cmin > d[tour[i]][tour[j]])
          cmin = d[tour[i]][tour[j]];
      if (cmax < d[tour[i]][tour[j]])
          cmax = d[tour[i]][tour[j]];
    }

    int next = i + 1;      // Find the next city to insert, biased on lower cost
    while (d[tour[i]][tour[next]] > cmin + alpha * (cmax - cmin))
      ++next;        // Cities to insert in random order; first choice is random
    swap(tour + (i+1), tour + next);
  } 
  int length = tsp_length(n, d, tour);
  tsp_LK(n, d, tour, &length);            // Improvement method: LK local search
  return length;
} // tsp_GRASP
