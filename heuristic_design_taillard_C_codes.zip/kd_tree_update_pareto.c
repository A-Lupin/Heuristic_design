/******* Test if root is in the rectangular box delimited by min and max ******/
int KD_in(KD_TREE root, KEY min, KEY max)
{ for (int i = 0; i < K; ++i)
    if(root->key[i] < min[i] || root->key[i] >max[i])
      return 0;
  return 1;
}

/** Returns the root of a tree in box [min, max] with its depth; NULL if none */
KD_TREE* KD_find(KD_TREE *tree, KEY min, KEY max, int depth, int *depth_found)
{ if ((*tree) == NULL)                              // tree empty: no node found
    return NULL;
  if (KD_in(*tree, min, max))                  // The root of tree is in the box
  { *depth_found = depth;
    return tree;
  }
  KD_TREE* res;
  if (max[depth%K] >= (*tree)->key[depth%K] &&         // Look at right sub-tree
      (res = KD_find(&(*tree)->r, min, max, depth + 1, depth_found)) != NULL)
    return res; 
  if (min[depth%K] <= (*tree)->key[depth%K])                 // Look at the left
    return KD_find(&(*tree)->L, min, max, depth + 1, depth_found);
  return NULL;                                                  // No node found
}

/*** Looks if point should be added to a pareto set represented by a KD-tree **/
/* Remove dominated points and then recursively add non-dominated neighbours  */
void update_pareto(KD_TREE *pareto, KEY costs, int n, int *info, int*** data) 
{ KEY min, max;       // Ideal and nadir points for multi-objective minimization
  for (int dim = 0; dim < K; ++dim)
  { min[dim] = 0; max[dim] = INT_MAX;}

  int depth;
  if (KD_find(pareto, min, costs, 0, &depth) == NULL)   // costs improves Pareto
  { KD_TREE *dominated;         // Find and remove all points dominated by costs
    while( (dominated = KD_find(pareto, costs, max, 0, &depth)) != NULL)
      KD_delete(dominated, depth);           

    KD_add(pareto, costs, n, info, 0);

    tsp_3opt_pareto(pareto, costs, n, info, data);                  // Code %*\ref{lst:tsp_3opt_pareto}*)
  }
}




