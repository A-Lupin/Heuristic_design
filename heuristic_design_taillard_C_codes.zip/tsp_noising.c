void tsp_noising(int n,                                      // Number of cities
                 int** d,                // Distance matrix, must be symmetrical
                 int best_tour[],        // InOut Solution provided and returned
                 int* best_length,              // InOut Length of the best tour
                 double initial_noise,                             // Parameters
                 double final_noise,
                 double alpha)

{ int length = *best_length;                           // Length of current tour
  
  double noise, current_noise = initial_noise;          // Current maximal noise
  int* t = build_2opt_data_structure(n, best_tour);

  long iteration = 0;                          // Number of iterations performed
  while (current_noise > final_noise)         // Repeat, while noise high enough
  { int i = 0;                             // Start moves evaluation from city 0
    while (t[t[i]]>>1 && t[i]>>1)   // Index i arrived at the last to consider ?
     {int j = t[t[i]];
      while (j>>1 && (t[j]>>1 || i>>1) )
      { int delta = d[i>>1][j>>1]    + d[t[i]>>1][t[j]>>1]
                   -d[i>>1][t[i]>>1] - d[j>>1][t[j]>>1];
        noise = (rando() -0.5) * current_noise;
        if (delta + noise < 0)        // Move accepted */
        { int next_i = t[i], next_j = t[j];
          t[i] = j^1; t[next_i^1] = next_j;
          t[j] = i^1; t[next_j^1] = next_i;
          length = length + delta;
          i = t[i];               // Avoid immediate reverse of a degrading move
          j = t[i];

         if (length < *best_length)           // Memorize improved best solution
          { *best_length = length;
            tsp_2opt_data_structure_to_tour(n, t, best_tour);
            printf("Noising method improvement %ld %d\n", iteration, length);
          }
        }    // Move accepted */
        ++iteration;
        if (iteration % (n * n) == 0)      // Noise decrease every n*n iteration
          current_noise *= alpha;
        j = t[j];  // Next j
      }
      i = t[i]; // Next i
    }
  } // while (current_noise > final_noise)
  free(t);
} // tsp_noising
