int generate_solution_trail(int n,                           // Number of cities
                            int **d,                          // Distance matrix
                            int tour[],              // Tour produced by the ant
                            int **trail)                     // Pheromone trails
{ for (int i = 1; i < n-1; ++i)
  { int sum = 0;
    for (int j = i + 1; j < n; ++j)
      sum += trail[tour[i-1]][tour[j]];
    int j, target = unif(0, sum - 1);
    for(j = i, sum = trail[tour[i-1]][tour[j]]; sum < target; ++j)
      sum += trail[tour[i-1]][tour[j+1]];
    swap(tour + j, tour + i);
  }
  return tsp_length(n, d, tour);
} // generate_solution_trail
