/*****************************************************************************
Compile: gcc -O2 test_tsp_2_and_3opt.c
Example of execution:
Number of cities:
500
Random solution: 24565
Cost of solution found with 2-opt first 953
Solution improved with 3-opt limited (100 cities) 738
Solution improved with complete 3-opt 679
Solution improved with 2-opt best 673
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "random_generators.c"             // Code %*\ref{lst:random_generators}*)
#include "tsp_utilities.c"                 // Code %*\ref{lst:tsp_utilities}*)
#include "build_2opt_data_structure.c"     // Code %*\ref{lst:build_2opt_data_structure}*)
#include "tsp_2opt_first.c"                // Code %*\ref{lst:tsp_2opt_first}*)
#include "tsp_2opt_best.c"                 // Code %*\ref{lst:tsp_2opt_best}*)
#include "tsp_3opt_limited.c"              // Code %*\ref{lst:tsp_3opt_limited}*)
#include "tsp_3opt_first.c"                // Code %*\ref{lst:tsp_3opt_first}*)

int main(void)
{ int n;
  printf("Number of cities:\n");
  scanf("%d",&n);
  int** distance = rand_sym_matrix(n, 1, 99);
  int* solution = (int*) malloc((size_t)n * sizeof(int));
  
  rand_permutation(n, solution);
  int length = tsp_length(n, distance, solution);
  printf("Random solution: %d\n", length);

  tsp_2opt_first(n, distance, solution, &length);
  printf("Cost of solution found with 2-opt first %d\n", length);

  int* succ = (int*) malloc((size_t)n * sizeof(int));
  tsp_tour_to_succ(n, solution, succ);
  tsp_3opt_limited(n, distance, 100, succ, &length);
  printf("Solution improved with 3-opt limited (100 cities) %d\n", length);

  tsp_3opt_first(distance, succ, &length);
  printf("Solution improved with complete 3-opt %d\n", length);

  tsp_succ_to_tour(n, succ, solution);
  tsp_2opt_best(n, distance, solution, &length);
  printf("Solution improved with 2-opt best %d\n", length);

  for (int i = 0; i < n; ++i)
    free(distance[i]); 
  free(distance);
  free(solution);
  free(succ);
}

