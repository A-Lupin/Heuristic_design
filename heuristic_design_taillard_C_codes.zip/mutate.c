/* Mutation operator for permutation perform mutation_rate*n/2 random swaps   */
void mutate(int n,                                           // Permutation size
            double mutation_rate,
            int p[])                                    // Permutation to mutate
{ int mutations = (int)(mutation_rate * n / 2.0);
  for(int i = 0; i < mutations; ++i)
    swap(p + unif(0, n - 1), p + unif(0, n - 1));
} // mutate
