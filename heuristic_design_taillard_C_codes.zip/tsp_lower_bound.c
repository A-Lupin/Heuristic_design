int tsp_lower_bound(int n, int** d,         // Number of cities, distance matrix
                    int depth,                   // tour[0] to tour[depth] fixed
                    int tour[],         // Solution; last cities can be shuffled
                    int* valid)          // Indicate if returned tour is optimum
{ // Compute the length of the path for the cities already fixed in tour
  int lb = 0;    
  for (int j = 0; j < depth; ++j)
    lb += d[tour[j]][tour[j+1]];
  // Add the length to the closest free city j
  *valid = 1;       // valid is set to 1 if every closest successor build a tour
  for (int j = depth; j < n - 1; ++j)
  { int minimum = d[tour[j]][tour[j+1]];
    for (int k = n - 1; k > depth; --k)
      if (k != j && minimum > d[tour[j]][tour[k]])
      { minimum = d[tour[j]][tour[k]]; 
        if (k > j)
          swap(tour + k, tour + j + 1);
        else
          *valid = 0;
      }
    lb += minimum;
  }
  int minimum = d[tour[n-1]][tour[0]];     //Come back to first city of the tour
  for (int j = depth + 1; j < n - 1; ++j)
    if (minimum > d[tour[j]][tour[0]])
    { *valid = 0; minimum = d[tour[j]][tour[0]];}
  return lb + minimum;
} // tsp_lower_bound
