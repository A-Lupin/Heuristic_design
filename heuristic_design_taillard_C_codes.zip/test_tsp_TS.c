/*****************************************************************************
Compile: gcc -O2 test_tsp_TS.c
Example of execution:
Number of cities:
30
Number of tabu iterations, min. and max. tabu_duration, penalty:
200 4 20 0.005
TS 1 1190
TS 2 1053
TS 3 906
TS 4 796
...
TS 26 179
TS 29 177
TS 46 174
TS 119 173
Cost of tour found with TS 173

******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <values.h>

#include "random_generators.c"             // Code %*\ref{lst:random_generators}*)
#include "tsp_utilities.c"                 // Code %*\ref{lst:tsp_utilities}*)
#include "tsp_TS.c"                        // Code %*\ref{lst:tsp_TS}*)

int main(void)
{ int n, iterations, min_tabu, max_tabu;
  double freq_penalty;

  printf("Number of cities:\n");
  scanf("%d",&n);

  int** distance = rand_sym_matrix(n, 1, 99);
  int* tour = (int*) malloc((size_t)n * sizeof(int));  
  rand_permutation(n, tour);
  int length = tsp_length(n, distance, tour);

  printf("Number of tabu iterations, min. and max. tabu_duration, penalty:\n");
  scanf("%d%d%d%lf",&iterations, &min_tabu, &max_tabu, & freq_penalty);
  tsp_TS(n, distance, tour, &length,
         iterations, min_tabu, max_tabu, freq_penalty);
  printf("Cost of tour found with TS %d\n", length);

  for (int i = 0; i < n; ++i)
    free(distance[i]); 
  free(distance);
  free(tour);
}

