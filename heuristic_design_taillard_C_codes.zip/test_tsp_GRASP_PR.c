/*****************************************************************************
Compile: gcc -O2 test_tsp_GRASP.c -lm
Example of run:
Number of cities:
200
Number of iterations:
50
Population size:
10
GRASP alpha parameter:
0.7
GRASP_PR population updated: 16 320
GRASP_PR population updated: 18 316
GRASP_PR population updated: 19 315
GRASP_PR population updated: 21 309
GRASP_PR population updated: 35 316
GRASP_PR population updated: 40 313
GRASP_PR population updated: 42 311
GRASP with path relinking: 309

******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include <math.h>
#include "random_generators.c"             // Code %*\ref{lst:random_generators}*)
#include "tsp_utilities.c"                 // Code %*\ref{lst:tsp_utilities}*)
#include "tsp_LK.c"                        // Code %*\ref{lst:tsp_LK}*)
#include "tsp_GRASP.c"                     // Code %*\ref{lst:tsp_GRASP}*)
#include "tsp_path_relinking.c"            // Code %*\ref{lst:tsp_path_relinking}*)
#include "tsp_GRASP_PR.c"                  // Code %*\ref{lst:tsp_GRASP_PR}*)

int main(void)
{ int n, iterations, pop_size;
  double alpha;

  printf("Number of cities:\n");
  scanf("%d",&n);
  printf("Number of iterations:\n");
  scanf("%d",&iterations);
  printf("Population size:\n");
  scanf("%d",&pop_size);
  printf("GRASP alpha parameter:\n");
  scanf("%lf",&alpha);

  int* solution = (int*) malloc((size_t)n * sizeof(int));
  int** distance = rand_sym_matrix(n, 1, 99);
  printf("GRASP with path relinking: %d\n",
         tsp_GRASP_PR(n, distance, solution, pop_size, iterations, alpha));

  for (int i = 0; i < n; ++i)
    free(distance[i]); 
  free(solution);
}

